#ifndef CENTERWIDGET_H
#define CENTERWIDGET_H

#include <QWidget>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QPushButton>
class CenterWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CenterWidget(QWidget *parent = nullptr);

    void paintEvent(QPaintEvent *);
    void setDrawType(int type);
    void colorEvent(QPaintEvent *);
    void setColor(int type);
    //void setFill(int type);
signals:
protected:
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void keyPressEvent(QKeyEvent *e);
public slots:
    void Onfillclicked(bool);
private:
    QPixmap pixmap;
    QString mouseClickInfo;
    QString mousePosInfo;
    QString keyPressInfo;
    int drawType;
    int colorType;
    QPushButton *fill=new QPushButton;
    //int fillType;
};

#endif // CENTERWIDGET_H
