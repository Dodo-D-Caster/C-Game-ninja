#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "centerwidget.h"
#include <QMenu>
#include <QMenuBar>
#include <QAction>
#include <QToolBar>
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private:
    CenterWidget *centerWidget;
    QMenu *fileMenu;
    QMenu *drawMenu;
    QMenu *colorMenu;
//    QMenu *brushMenu;
    QAction *exitAction;
    QAction *lineAction;
    QAction *ellipseAction;
    QAction *rectangleAction;
    QAction *blackAction;
    QAction *greenAction;
    QAction *yellowAction;
    QToolBar *drawToolBar;
//    QPushButton *fillButton;
//    QAction *brushAction;
//    QAction *notbrushAction;
//    QAction *splitLineButton;/////////////////////////////
//    QFrame *frame;///////////////////////////////
protected slots:
    void line();
    void ellipse();
    void rectangle();
    void black();
    void green();
    void yellow();
//    void splitLine(QWidget *parent);/////////////////////
//    void brush();
//    void notbrush();
};
#endif // MAINWINDOW_H
