#include "centerwidget.h"
#include <QPainter>
#include <QPushButton>
#include "mainwindow.h"
CenterWidget::CenterWidget(QWidget *parent) : QWidget(parent)
{
    pixmap.load("flower.jpg");
    setMinimumSize(400,400);
    drawType=0;
    colorType=0;
    mouseClickInfo=tr("");
    mousePosInfo=tr("");
    keyPressInfo=tr("");
    setMouseTracking(true);
    this->grabKeyboard();

    fill->setParent(this);
    fill->setText("填充");
    connect(fill,SIGNAL(clicked(bool)),this,SLOT(Onfillclicked(bool)));
}
void CenterWidget::paintEvent(QPaintEvent *){
    QPainter p(this);
    switch(colorType){
    case 0:{
        QPen pen(Qt::black,2,Qt::SolidLine);
        p.setPen(pen);
        break;}
    case 1:{
        QPen pen(Qt::green,2,Qt::SolidLine);
        p.setPen(pen);
        break;}
    case 2:{
        QPen pen(Qt::yellow,2,Qt::SolidLine);
        p.setPen(pen);
        break;}
    }
    QPoint p1(50,50),p2(500,300);
    switch(drawType){
    case 0:
        p.drawLine(p1,p2);
        break;
    case 1:
        p.drawEllipse(QRect(p1,p2));
        break;
    case 2:
        p.drawRect(QRect(p1,p2));
        break;
    }
    p.drawText(550,200,mouseClickInfo);
    p.drawText(550,300,mousePosInfo);
    p.drawText(550,100,keyPressInfo);


    //connect(this,SIGNAL(clicked(bool)),this,SLOT(fill()));

//    switch(fillType){
//    case 0:
//        break;
//    case 1:
//        QBrush brush;
//        p.setBrush(brush);
//        break;
//    }
}
void CenterWidget::setDrawType(int type){
    drawType=type;
}
void CenterWidget::setColor(int type){
    colorType=type;
}
//void CenterWidget::setFill(int type){
//    fillType=type;
//}
void CenterWidget::mousePressEvent(QMouseEvent *e){
    mouseClickInfo=tr("Mouse Click at: ")+QString::number(e->x())
        +","+QString::number(e->y());
    update();
}
void CenterWidget::mouseMoveEvent(QMouseEvent *e){
    mousePosInfo=tr("Mouse pos: ")+QString::number(e->x())
        +","+QString::number(e->y());
    update();
}
void CenterWidget::keyPressEvent(QKeyEvent *e){
    keyPressInfo=tr("Key Press: ")+QString::number(e->key());
    update();
}
//void CenterWidget::fill(){
//    QPainter p(this);
//    QBrush brush;
//    p.setBrush(brush);
//}
void CenterWidget::Onfillclicked(bool){
    if(true){
      QPainter p(this);
      QBrush brush;
      p.setBrush(brush);
    }
}
